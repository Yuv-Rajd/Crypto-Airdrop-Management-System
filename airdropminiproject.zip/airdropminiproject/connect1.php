<?php 
         $servername="localhost:3307";
         $username="root";
         $password="";
         $dbname="apms";

         $con= mysqli_connect($servername,$username,$password,$dbname);

         if(!$con){
             die(" error in connecting database");
         }
?>