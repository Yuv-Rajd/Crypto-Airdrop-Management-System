<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>xvcvcvxc</title>
    <link href="css/hder.css" rel="stylesheet">
</head>
<body> 
    
<header>
<div class="hdr">

    <div class="nav">
        <ul>
           
            <li class="active">  
            <a href ="javascript:history.back()"><h2>AIRDŘOP</h2></a></li>
            <li>  <a href ="about.php">ABOUT</a></li>
            <li>  <a href="faq.php">FAQ</a></li>
            <li>  <a href ="contact.php">CONTACT</a></li>
            <!-- <li class="active"><a href="">>></a> <div class="fangle">
            <div class="sub-menu1">
               
                <ul >
                   
                    <li>  <a href ="adminpanel/alogin.php">admin login</a></li>
                    <li>  <a href ="login.php">logout</a></li>
                </ul>
            </div> -->
       
            
        </ul>

    </div>
</div>
</header>
  
</body>
</html>