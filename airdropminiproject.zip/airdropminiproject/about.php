<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ABOUT</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <link rel="stylesheet" href="styles1.css" />
    <link rel="stylesheet" href="css/about.css">
    <style>
        body{
            background:rgb(238,238,228);
        }
.main33{
    background:rgba(239,243,233,255);
   margin: 10px 10% 10px 10%;
   padding: 5px 5px 10px 5px;
}


    </style>
</head>
<body>
<?php include'header.php';  ?>
<div class="main33">
<div class ="mwrapp">
    <div class="wrap"></div>
    <h1 class="ah1">Our Team</h1>
  <div class="atflex">
    <div class="ateam">
        <div class="ateammember">
            <h3>YUVARAJA D</h3>
            <p class="arole">4UB19CS061</p>
            <p class="arole1">CSE 5th sem</p>
            <p class="arole1"> UBTCE davangere</p>
            <p>inventore voluptates tenetur, in vero, eveniet fugit natus alias. Animi velit reprehenderit eum.</p>

        </div>
         <div class="ateammember">
            <h3>VINAYAK S C</h3>
            <p class="arole">4UB19CS067</p>
            <p class="arole1">CSE 5th sem</p>
            <p class="arole1"> UBTCE davangere</p>
            <p> inventore voluptates tenetur, in vero, eveniet fugit natus alias. Animi velit reprehenderit eum.</p>

        </div>
   
    </div>
    
    




</div>

</div>


</div>
<?php include'footer.php';  ?>    
</body>
</html>